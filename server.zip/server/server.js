var express = require('express'),
bodyParser =require('body-parser'),
mongoose =require('mongoose'),
port= process.env.PORT || 3000, 

app=express();

// Pensez d'abord à installer Mongoose en tapant : npm install mongoose
var mongoose=require('mongoose');

mongoose.connect('mongodb://localhost/bdd_yami', function(err){
    if(err) {
        throw err;
    }
});

 
// Création du schéma pour mes utilisateurs
var mesUsers = new mongoose.Schema({
  nom : { type : String, match: /^[a-zA-Z0-9-_]+$/ },
  email : String,
  pwd : { String }
});
 
// Création du Model pour les users
var mesUsers = mongoose.model('users', mesUsers);
 
// Je crée une instance du Model
//var monUser = new mesUsers({ nom : 'bodenan', email: 'jovialbanga@gmail.com', pwd: 123456 });

 
// Je le sauvegarde dans MongoDB !
/* monUser.save(function (err) {
  if (err) { throw err; }
  console.log('Utilisateur ajouté avec succès !');
  // On se déconnecte de MongoDB maintenant
 // mongoose.connection.close();
}); */

var router = express.Router();
router.route('/api')
    .get(function(req, res){
        mesUsers.find(function(err,users){
            if(err){
                res.send(err);
            }
            res.send(users);
        });
    })
    .post(function(req,res){
        var user=new mesUsers();
        user.nom=req.body.nom;
        user.email=req.body.email;
        user.pwd=req.body.pwd;
        user.save(function(err){
            if(err){
                res.send(err);
            }
            res.send({message: 'Inscription réussie'});
             
        });
    });

app.use(bodyParser.urlencoded({extended: true})),
app.use(bodyParser.json()),
app.use(router);

    app.listen(port, function(){
        console.log('listen on port ' + port);
    });











